C# example calling QA Gateway on Bluemix.
