﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWatson1
{
    class Program
    {
        static void Main(string[] args)
        {
            WatsonQA travel = new WatsonQA("travel", 
                                           "https://gateway.watsonplatform.net/qagw/service", 
                                           "[enter uid here]", 
                                           "[enter pwd here]");

           var answers =  travel.AskQuestion("[enter question here]");
           Console.WriteLine(answers);
           Console.ReadKey();
        }
    }
}
